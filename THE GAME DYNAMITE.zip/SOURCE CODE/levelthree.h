#pragma once
// levelthree.h

#ifndef LEVELTHREE_H
#define LEVELTHREE_H

#include <SFML/Graphics.hpp>
#include <iostream>

void level3(sf::RenderWindow& window);

#endif // LEVELTHREE_H
