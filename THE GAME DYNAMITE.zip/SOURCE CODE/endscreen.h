#pragma once
//endscreen.h
#ifndef ENDSCREEN_H
#define ENDSCREEN_H

#include <SFML/Graphics.hpp>
#include <iostream>

void endscreen(sf::RenderWindow& window);

#endif // ENDSCREEN_H
