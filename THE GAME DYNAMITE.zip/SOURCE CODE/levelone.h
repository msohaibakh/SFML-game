// levelone.h

#ifndef LEVELONE_H
#define LEVELONE_H

#include <SFML/Graphics.hpp>
#include <iostream>

void level1(sf::RenderWindow& window);

#endif // LEVELONE_H
