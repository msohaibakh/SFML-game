// leveltwo.h

#ifndef LEVELTWO_H
#define LEVELTWO_H

#include <SFML/Graphics.hpp>
#include <iostream>

void level2(sf::RenderWindow& window);

#endif // LEVELTWO_H
