#pragma once
// environment.h

#ifndef ENVIRONMENT_H
#define ENVIRONMENT_H

#include <SFML/Graphics.hpp>
#include <iostream>

enum GameState {
    Loading,
    Menu
};

void enviro();

#endif // ENVIRONMENT_H
